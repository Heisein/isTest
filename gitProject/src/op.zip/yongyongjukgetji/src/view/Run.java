package view;

public class Run {
	public static void main(String[] args) {
		new Login();
	}
}
