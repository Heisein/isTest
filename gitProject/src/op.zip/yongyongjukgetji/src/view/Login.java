package view;

import java.awt.*;
import java.io.File;

import javax.imageio.stream.FileImageOutputStream;
import javax.swing.*;


public class Login {
	public Login() {
		JFrame jf = new JFrame("�뵷��");
		jf.setSize(360, 600);
		
		JPanel jp = new JPanel();
		jp.setBackground(new Color(117, 102, 205));
		
		JButton jb[] = new JButton[2];
		
		jb[0]=new JButton("�α���");
		jb[1]=new JButton("ȸ������");
		
		jb[0].setSize(300, 40);
		jb[1].setSize(300, 40);
	
		jb[0].setBackground(new Color(79, 69, 138));
		jb[1].setBackground(new Color(78, 74, 105));
		
		jb[0].setForeground(Color.WHITE);
		jb[1].setForeground(Color.WHITE);
		
		jb[0].setLocation(25, 367);
		jb[1].setLocation(25, 426);
		
		jp.setLayout(null);
		ImageIcon img = new ImageIcon("mainimg.png");
		JLabel jl = new JLabel(img);
		jl.setSize(200,224);
		jl.setLocation(75,80);
		jl.setVisible(true);
		
		jp.add(jb[0]);
		jp.add(jb[1]);
		jp.add(jl);
		
		
		
		
		
		
		
		
		
		
		

		jf.add(jp);
		jf.setVisible(true);
		jf.setDefaultCloseOperation(1);
	}

	private Insets insets(int i, int j, int k, int l) {
		// TODO Auto-generated method stub
		return null;
	}
}
